#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from brain_games.engine import start_game


def main():
  start_game()


if __name__ == '__main__':
  main()