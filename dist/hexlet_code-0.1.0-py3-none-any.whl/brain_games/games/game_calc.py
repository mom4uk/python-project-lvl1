
DESCRIPTION = 'What is the result of the expression?'